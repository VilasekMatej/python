"# projekt-python" 
